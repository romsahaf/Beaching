import React, { useState } from 'react';
import './App.css';
import Weather from './Weather';


function App() {
  const [tmp, setTmp] = useState("")

  const [desc, setDesc] = useState("")
  const [temp, setTemp] = useState("")
  const [clouds, setClouds] = useState("")
  const [city, setCity] = useState("")
  const [lat, setLat] = useState("")
  const [lon, setLon] = useState("")


  
  function handleSubmit(event){
    const url = "http://api.openweathermap.org/data/2.5/weather?appid=1538812f2c4a4735068cc20e62b4a5b6&q="+tmp+"&units=metric"

    event.preventDefault();
    fetch(url)
    .then(response => response.json())
    .then(data => {
      if(data.cod === "404"){
        setCity("City Not Found!")
      }
      else{
        setCity(tmp)
        setDesc(data.weather[0].description)
        setTemp(data.main.temp)
        setClouds(data.clouds.all)
        setLat(data.coord.lat)
        setLon(data.coord.lon)
      }
    }) 
  }

  function handleChange(event){
    setTmp(event.target.value)
  }

  if(city === "" || city === "City Not Found!"){
    return (
      <div className="opendiv">
        <header>
          <h1>Beaching</h1>
          <h4>The App that tells you to go to the beach (or not...)</h4>
        </header>
        <form className= "form1" onSubmit={handleSubmit}>
          City Name:
          <input type="text" value={tmp} onChange={handleChange} placeholder="Enter a city name" className="input-text" />
          <input type="submit" value="GO!" className="input-submit"/>
          <p>
            {city}
          </p>
        </form>
      </div>
    ) 
  }

  else{
    var beach = true
    if(temp < 23 || (desc !== 'clear sky' && desc !== 'few clouds')){
      document.body.classList.add('background-grey')
      beach = false
    }
    else
      document.body.classList.add('background-clear')
    return <Weather city={city} desc={desc} temp={temp} clouds={clouds} beach={beach} lat={lat} lon={lon}/>
  }
}
export default App