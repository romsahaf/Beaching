import React, { useState, useEffect } from 'react';
import Forecast from './Forecast'
function Weather(props){
    const [uv, setUv] = useState("...")
    const [forecast, setForecast] = useState([])
    var icon = "sunny";
    var desc1 = "It's a GREAT day to go to the beach!"
    var desc2 = "With " + props.desc + ", Temperatures as high as " + props.temp + "° and UV index of "+uv
    var url1 = "http://api.openweathermap.org/data/2.5/uvi?appid=1538812f2c4a4735068cc20e62b4a5b6&lat="+props.lat+"&lon="+props.lon
    var url2 = "http://api.openweathermap.org/data/2.5/forecast?appid=1538812f2c4a4735068cc20e62b4a5b6&q="+props.city+"&units=metric"
    
    fetch(url1)
    .then(response => response.json())
    .then(data => {
        setUv(data.value)
    })
    

    useEffect(() => {
        fetch(url2)
        .then(response => response.json())
        .then(data => {
            const ans = data.list.filter(sample => {
                return sample.dt_txt.includes("12:00:00")
            })
            setForecast(ans)
        })
    }, [])

    if(!props.beach)
        icon = "rainy"
    
    if(props.desc !== 'clear sky' && props.desc !== 'few clouds'){
        desc1 = "It's NOT a good day for the beach!" 
        desc2 = "Due to " + props.desc
    }

    else{
        if(props.temp < 23){
            desc1 = "It's NOT a good day for the beach!"
            desc2 = "Due to temperatures as low as " + props.temp +"°"
        }
    }
        console.log(forecast)

        var ans = ""
        if(forecast.length > 4)
            ans = 
            <div className="forcast-wrap">
                <Forecast date={forecast[0].dt_txt} desc={forecast[0].weather[0].description} temp={forecast[0].main.temp} clouds={forecast[0].clouds.all}/>
                <Forecast date={forecast[1].dt_txt} desc={forecast[1].weather[0].description} temp={forecast[1].main.temp} clouds={forecast[1].clouds.all}/>
                <Forecast date={forecast[2].dt_txt} desc={forecast[2].weather[0].description} temp={forecast[2].main.temp} clouds={forecast[2].clouds.all}/>
                <Forecast date={forecast[3].dt_txt} desc={forecast[3].weather[0].description} temp={forecast[3].main.temp} clouds={forecast[3].clouds.all}/>
                <Forecast date={forecast[4].dt_txt} desc={forecast[4].weather[0].description} temp={forecast[4].main.temp} clouds={forecast[4].clouds.all}/>
            </div>
    return(
        <>
            <div className="weather">
                <h3>
                <img src={icon+".jpg"} className="imgBig" height="180" width="220" alt="fuck"/>
                {desc1}
                </h3>
                <b>{desc2}</b><br/>
                <br/>
                <u><b>City:</b></u> {props.city.charAt(0).toUpperCase()+props.city.slice(1)} <br/>
                <u><b>Weather:</b></u> {props.desc.charAt(0).toUpperCase()+props.desc.slice(1)} <br/>
                <u><b>Temperature:</b></u> {props.temp}° <br/>
                <u><b>Clouds:</b></u> {props.clouds}% <br/>
                <u><b>UV index:</b></u> {uv} <br/>
            </div>
            {ans}
        </>
    )
}

export default Weather