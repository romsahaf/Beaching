
import React from 'react';

function Forecast(props){
    var icon = "sunny";
    if((props.desc !== 'clear sky' && props.desc !== 'few clouds') || props.temp < 23){
        icon = "rainy"
    }

    var tmp = props.date.slice(0,10)
    
    return(
        <div className="forecast">
            <h6>
            <img src={icon+".jpg"} className="imgSmall" height="60" width="80" alt="fuck"/><br/>
            <u>Date:</u> {tmp.slice(-2) + tmp.slice(4, 7)} <br/>
            <u>Weather:</u> {props.desc.charAt(0).toUpperCase()+props.desc.slice(1)} <br/>
            <u>Temperature:</u> {props.temp}° <br/>
            <u>Clouds:</u> {props.clouds}% <br/>
            </h6>
        </div>
    )
}

export default Forecast;