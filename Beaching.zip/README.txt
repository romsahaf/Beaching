
Beaching is an app that tells you whether you should head for the beach today or not.

It does that by getting weather conditions form OPENWEATHER, and determines if the
conditions are good for the beach or not (based on clouds coverage, precipitations,
temperatures, ultraviolet index etc.)

The app offers a glimpse to upcoming conditions for the next 5 days as well.


HOW TO START THE APP:

- Open the command line on any folder and type 'create-react-app beaching' 
  and wait for the installation to create all files and folders

- copy and replace the 'src' and 'public' folders from my git to the 'beaching' folder

- Open the command line on the 'beaching' folder.

- type 'npm start'

- when the browser is open and the app is running, 
  enter the city you wish to beach in, and press GO!